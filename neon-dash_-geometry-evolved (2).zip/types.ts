
export enum GameState {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  GAMEOVER = 'GAMEOVER',
  SHOP = 'SHOP',
  LEVEL_SELECT = 'LEVEL_SELECT'
}

export interface Hat {
  id: string;
  name: string;
  icon: string;
}

export interface Skin {
  id: string;
  name: string;
  color: string;
  secondaryColor: string;
  icon: string;
  trailColor: string;
}

export interface Environment {
  id: string;
  name: string;
  bgColor: string;
  floorColor: string;
  gradient: string;
  musicUrl: string;
}

export interface Obstacle {
  x: number;
  y: number;
  type: 'spike' | 'block' | 'portal';
}

export interface Level {
  id: string;
  name: string;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Demon';
  obstacles: Obstacle[];
  environmentId: string;
}
