
import React, { useEffect, useRef, useCallback } from 'react';
import { GameState, Skin, Level, Hat } from '../types';
import { GRAVITY, JUMP_FORCE, SPEED, PLAYER_SIZE, GROUND_Y, ENVIRONMENTS } from '../constants';

interface GameEngineProps {
  gameState: GameState;
  skin: Skin;
  hat: Hat;
  level: Level;
  onGameOver: (score: number) => void;
}

const GameEngine: React.FC<GameEngineProps> = ({ gameState, skin, hat, level, onGameOver }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>(null);
  
  const playerRef = useRef({
    x: 150,
    y: GROUND_Y - PLAYER_SIZE,
    vy: 0,
    rotation: 0,
    isGrounded: true,
    trail: [] as { x: number; y: number }[]
  });

  const scrollX = useRef(0);
  const environment = ENVIRONMENTS.find(e => e.id === level.environmentId) || ENVIRONMENTS[0];

  useEffect(() => {
    if (gameState === GameState.PLAYING) {
      playerRef.current = {
        x: 150,
        y: GROUND_Y - PLAYER_SIZE,
        vy: 0,
        rotation: 0,
        isGrounded: true,
        trail: []
      };
      scrollX.current = 0;
    }
  }, [gameState, level.id]);

  const handleInput = useCallback(() => {
    if (gameState !== GameState.PLAYING) return;
    if (playerRef.current.isGrounded) {
      playerRef.current.vy = JUMP_FORCE;
      playerRef.current.isGrounded = false;
    }
  }, [gameState]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') handleInput();
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('mousedown', handleInput);
    window.addEventListener('touchstart', handleInput);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('mousedown', handleInput);
      window.removeEventListener('touchstart', handleInput);
    };
  }, [handleInput]);

  const update = () => {
    if (gameState !== GameState.PLAYING) return;

    const p = playerRef.current;
    p.vy += GRAVITY;
    p.y += p.vy;
    
    let onAnySurface = false;

    // Проверка коллизии с полом
    if (p.y >= GROUND_Y - PLAYER_SIZE) {
      p.y = GROUND_Y - PLAYER_SIZE;
      p.vy = 0;
      onAnySurface = true;
    }

    scrollX.current += SPEED;
    const curX = p.x;

    // Проверка коллизий с объектами
    for (const obs of level.obstacles) {
      const obsX = obs.x - scrollX.current;
      
      // Пропускаем далекие объекты
      if (obsX < -100 || obsX > 1000) continue;

      if (obs.type === 'spike') {
        // Коллизия с шипами (смерть)
        if (curX + PLAYER_SIZE - 10 > obsX + 5 && curX + 10 < obsX + 45) {
          if (p.y + PLAYER_SIZE > GROUND_Y - 45) {
            onGameOver(Math.min(100, Math.floor((scrollX.current / 4000) * 100)));
            return;
          }
        }
      } else if (obs.type === 'block') {
        const blockTop = GROUND_Y - obs.y - 50;
        const blockBottom = GROUND_Y - obs.y;
        const blockLeft = obsX;
        const blockRight = obsX + 50;

        // Проверка пересечения
        if (curX + PLAYER_SIZE > blockLeft && curX < blockRight && 
            p.y + PLAYER_SIZE > blockTop && p.y < blockBottom) {
          
          // Проверяем, упали ли мы сверху (с небольшим порогом)
          const fallDistance = (p.y + PLAYER_SIZE) - blockTop;
          if (p.vy >= 0 && fallDistance < 20) {
            p.y = blockTop - PLAYER_SIZE;
            p.vy = 0;
            onAnySurface = true;
          } else {
            // Столкновение со стенкой блока или удар снизу
            onGameOver(Math.min(100, Math.floor((scrollX.current / 4000) * 100)));
            return;
          }
        }
      }
    }

    p.isGrounded = onAnySurface;
    if (!p.isGrounded) {
      p.rotation += 5;
    } else {
      p.rotation = Math.round(p.rotation / 90) * 90;
    }

    p.trail.push({ x: p.x + scrollX.current, y: p.y + PLAYER_SIZE / 2 });
    if (p.trail.length > 20) p.trail.shift();
  };

  const draw = (ctx: CanvasRenderingContext2D) => {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    // Фоновый градиент
    const grad = ctx.createLinearGradient(0, 0, 0, ctx.canvas.height);
    grad.addColorStop(0, environment.bgColor);
    grad.addColorStop(1, '#000000');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    // Пол
    ctx.fillStyle = environment.floorColor;
    ctx.fillRect(0, GROUND_Y, ctx.canvas.width, ctx.canvas.height - GROUND_Y);
    ctx.strokeStyle = skin.color;
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(0, GROUND_Y); ctx.lineTo(ctx.canvas.width, GROUND_Y); ctx.stroke();

    // Шлейф
    ctx.beginPath();
    ctx.strokeStyle = skin.trailColor;
    ctx.lineWidth = 10;
    ctx.lineCap = 'round';
    playerRef.current.trail.forEach((pos, i) => {
      const drawX = pos.x - scrollX.current;
      if (i === 0) ctx.moveTo(drawX, pos.y); else ctx.lineTo(drawX, pos.y);
    });
    ctx.stroke();

    // Препятствия
    level.obstacles.forEach(obs => {
      const obsX = obs.x - scrollX.current;
      if (obsX < -100 || obsX > ctx.canvas.width + 100) return;
      if (obs.type === 'spike') {
        ctx.fillStyle = '#ff3333';
        ctx.shadowBlur = 15; ctx.shadowColor = '#ff3333';
        ctx.beginPath(); ctx.moveTo(obsX, GROUND_Y); ctx.lineTo(obsX + 25, GROUND_Y - 50); ctx.lineTo(obsX + 50, GROUND_Y); ctx.fill();
        ctx.shadowBlur = 0;
      } else if (obs.type === 'block') {
        ctx.fillStyle = '#1a1a1a';
        ctx.strokeStyle = skin.color;
        ctx.lineWidth = 2;
        ctx.strokeRect(obsX, GROUND_Y - obs.y - 50, 50, 50);
        ctx.fillRect(obsX, GROUND_Y - obs.y - 50, 50, 50);
        // Внутренний узор блока
        ctx.strokeRect(obsX + 10, GROUND_Y - obs.y - 40, 30, 30);
      }
    });

    // Игрок
    const p = playerRef.current;
    ctx.save();
    ctx.translate(p.x + PLAYER_SIZE / 2, p.y + PLAYER_SIZE / 2);
    ctx.rotate((p.rotation * Math.PI) / 180);
    ctx.shadowBlur = 20; ctx.shadowColor = skin.color;
    ctx.fillStyle = skin.color;
    ctx.fillRect(-PLAYER_SIZE / 2, -PLAYER_SIZE / 2, PLAYER_SIZE, PLAYER_SIZE);
    ctx.strokeStyle = skin.secondaryColor;
    ctx.lineWidth = 4;
    ctx.strokeRect(-PLAYER_SIZE / 2 + 8, -PLAYER_SIZE / 2 + 8, PLAYER_SIZE - 16, PLAYER_SIZE - 16);
    
    if (hat.id !== 'none') {
        ctx.font = '24px serif';
        ctx.textAlign = 'center';
        const hatEmoji = hat.id === 'crown' ? '👑' : hat.id === 'wizard' ? '🧙‍♂️' : hat.id === 'cowboy' ? '🤠' : '🎓';
        ctx.fillText(hatEmoji, 0, -PLAYER_SIZE/2);
    }
    ctx.restore();
  };

  const animate = useCallback(() => {
    update();
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) draw(ctx);
    }
    requestRef.current = requestAnimationFrame(animate);
  }, [gameState, skin, level, hat]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => { if (requestRef.current) cancelAnimationFrame(requestRef.current); };
  }, [animate]);

  return <canvas ref={canvasRef} width={1000} height={600} className="w-full h-full object-contain" />;
};

export default GameEngine;
