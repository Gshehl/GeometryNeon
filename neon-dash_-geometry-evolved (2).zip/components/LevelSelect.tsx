
import React from 'react';
import { Level } from '../types';
import { LEVELS, ENVIRONMENTS } from '../constants';

interface LevelSelectProps {
  onSelect: (level: Level) => void;
  onBack: () => void;
}

const LevelSelect: React.FC<LevelSelectProps> = ({ onSelect, onBack }) => {
  return (
    <div className="p-8 h-full bg-slate-950 overflow-y-auto">
      <div className="flex items-center justify-between mb-10">
        <h2 className="text-4xl font-bold font-title text-indigo-400">SELECT MISSION</h2>
        <button onClick={onBack} className="px-6 py-2 bg-slate-800 hover:bg-slate-700 rounded-full transition-colors">
          <i className="fa-solid fa-arrow-left mr-2"></i> BACK
        </button>
      </div>

      <div className="flex flex-col gap-4">
        {LEVELS.map(lvl => {
          const env = ENVIRONMENTS.find(e => e.id === lvl.environmentId);
          return (
            <div 
              key={lvl.id}
              onClick={() => onSelect(lvl)}
              className="group cursor-pointer p-6 rounded-2xl bg-slate-900 hover:bg-slate-800 border-l-8 transition-all flex items-center justify-between"
              style={{ borderLeftColor: lvl.difficulty === 'Easy' ? '#4ade80' : lvl.difficulty === 'Medium' ? '#fbbf24' : '#f87171' }}
            >
              <div>
                <h3 className="text-2xl font-bold mb-1">{lvl.name}</h3>
                <p className="text-slate-400 uppercase tracking-widest text-sm flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded text-[10px] ${
                    lvl.difficulty === 'Easy' ? 'bg-green-900 text-green-300' : 'bg-orange-900 text-orange-300'
                  }`}>
                    {lvl.difficulty}
                  </span>
                  • {env?.name}
                </p>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right hidden sm:block">
                  <div className="text-xs text-slate-500 mb-1">BEST ATTEMPT</div>
                  <div className="text-lg font-mono">0%</div>
                </div>
                <div className="w-12 h-12 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 group-hover:scale-125 transition-transform">
                  <i className="fa-solid fa-play"></i>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LevelSelect;
