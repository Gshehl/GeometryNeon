
import React from 'react';
import { GameState } from '../types';

interface MenuProps {
  onStart: () => void;
  onOpenShop: () => void;
  onOpenLevelSelect: () => void;
}

const Menu: React.FC<MenuProps> = ({ onStart, onOpenShop, onOpenLevelSelect }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full w-full bg-black/40 backdrop-blur-sm">
      <h1 className="text-8xl font-black font-title text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-600 mb-12 italic tracking-tighter animate-pulse">
        NEON DASH
      </h1>
      
      <div className="flex flex-col gap-6 w-full max-w-md px-4">
        <button 
          onClick={onStart}
          className="group relative px-8 py-6 bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-3xl rounded-xl transition-all duration-300 transform hover:scale-105 active:scale-95 shadow-[0_0_30px_rgba(34,211,238,0.5)]"
        >
          <i className="fa-solid fa-play mr-4 group-hover:rotate-12 transition-transform"></i>
          PLAY NOW
        </button>

        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={onOpenShop}
            className="px-6 py-4 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xl rounded-xl transition-all transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-3"
          >
            <i className="fa-solid fa-palette"></i>
            SKINS
          </button>
          
          <button 
            onClick={onOpenLevelSelect}
            className="px-6 py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xl rounded-xl transition-all transform hover:-translate-y-1 shadow-lg flex items-center justify-center gap-3"
          >
            <i className="fa-solid fa-layer-group"></i>
            LEVELS
          </button>
        </div>
      </div>

      <div className="mt-16 text-slate-500 animate-bounce flex items-center gap-2">
        <i className="fa-solid fa-keyboard"></i>
        <span>Press SPACE or TAP to Jump</span>
      </div>
    </div>
  );
};

export default Menu;
