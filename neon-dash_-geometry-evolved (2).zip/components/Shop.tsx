
import React, { useState } from 'react';
import { Skin, Hat } from '../types';
import { SKINS, HATS } from '../constants';

interface ShopProps {
  currentSkin: Skin;
  currentHat: Hat;
  onSelectSkin: (skin: Skin) => void;
  onSelectHat: (hat: Hat) => void;
  onBack: () => void;
}

const Shop: React.FC<ShopProps> = ({ currentSkin, currentHat, onSelectSkin, onSelectHat, onBack }) => {
  const [tab, setTab] = useState<'skins' | 'hats'>('skins');

  return (
    <div className="p-8 h-full bg-slate-950 overflow-y-auto">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-4xl font-bold font-title text-cyan-400">CHARACTER LAB</h2>
        <div className="flex gap-4">
            <button 
                onClick={() => setTab('skins')}
                className={`px-6 py-2 rounded-full font-bold transition-all ${tab === 'skins' ? 'bg-cyan-500 text-black' : 'bg-slate-800 text-slate-400'}`}
            >SKINS</button>
            <button 
                onClick={() => setTab('hats')}
                className={`px-6 py-2 rounded-full font-bold transition-all ${tab === 'hats' ? 'bg-cyan-500 text-black' : 'bg-slate-800 text-slate-400'}`}
            >HATS</button>
            <button onClick={onBack} className="px-6 py-2 bg-red-500 hover:bg-red-400 text-white font-bold rounded-full">
                <i className="fa-solid fa-xmark mr-2"></i> EXIT
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {tab === 'skins' ? SKINS.map(skin => (
          <div 
            key={skin.id}
            onClick={() => onSelectSkin(skin)}
            className={`cursor-pointer group relative p-4 rounded-xl transition-all border-2 ${
              currentSkin.id === skin.id ? 'bg-slate-800 border-cyan-400' : 'bg-slate-900 border-transparent hover:border-slate-700'
            }`}
          >
            <div className="flex flex-col items-center gap-4 text-center">
              <div 
                className="w-16 h-16 rounded-lg flex items-center justify-center text-3xl shadow-lg"
                style={{ backgroundColor: skin.color, color: skin.secondaryColor, boxShadow: `0 0 15px ${skin.color}` }}
              >
                <i className={`fa-solid ${skin.icon}`}></i>
              </div>
              <h3 className="font-bold">{skin.name}</h3>
            </div>
          </div>
        )) : HATS.map(hat => (
            <div 
              key={hat.id}
              onClick={() => onSelectHat(hat)}
              className={`cursor-pointer group relative p-4 rounded-xl transition-all border-2 ${
                currentHat.id === hat.id ? 'bg-slate-800 border-yellow-400' : 'bg-slate-900 border-transparent hover:border-slate-700'
              }`}
            >
              <div className="flex flex-col items-center gap-4 text-center">
                <div className="w-16 h-16 rounded-lg flex items-center justify-center text-3xl bg-slate-800 text-yellow-400">
                  <i className={`fa-solid ${hat.icon}`}></i>
                </div>
                <h3 className="font-bold">{hat.name}</h3>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default Shop;
