
import React, { useState, useCallback } from 'react';
import { GameState, Skin, Level, Hat } from './types';
import { SKINS, LEVELS, ENVIRONMENTS, HATS } from './constants';
import GameEngine from './components/GameEngine';
import Menu from './components/Menu';
import Shop from './components/Shop';
import LevelSelect from './components/LevelSelect';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.MENU);
  const [currentSkin, setCurrentSkin] = useState<Skin>(SKINS[0]);
  const [currentHat, setCurrentHat] = useState<Hat>(HATS[0]);
  const [currentLevel, setCurrentLevel] = useState<Level>(LEVELS[0]);
  const [score, setScore] = useState(0);

  const environment = ENVIRONMENTS.find(e => e.id === currentLevel.environmentId) || ENVIRONMENTS[0];

  const handleGameOver = useCallback((finalScore: number) => {
    setScore(finalScore);
    setGameState(GameState.GAMEOVER);
  }, []);

  const resetAndPlay = useCallback(() => {
    setScore(0);
    setGameState(GameState.PLAYING);
  }, []);

  const selectLevelAndGo = useCallback((lvl: Level) => {
    setCurrentLevel(lvl);
    setGameState(GameState.MENU);
  }, []);

  return (
    <div className={`relative w-full h-screen overflow-hidden bg-black transition-colors duration-1000 bg-gradient-to-b ${environment.gradient}`}>
      {/* Background visual effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
        <div className="absolute -top-1/2 -left-1/2 w-[200%] h-[200%] animate-[spin_60s_linear_infinite] bg-[radial-gradient(circle,rgba(255,255,255,0.05)_1%,transparent_1%)] bg-[length:50px_50px]"></div>
      </div>

      <div className="relative w-full h-full flex items-center justify-center p-4">
        <div className="w-full max-w-5xl aspect-[10/6] bg-black rounded-3xl overflow-hidden shadow-[0_0_80px_rgba(0,0,0,0.9)] border border-slate-800 relative">
          
          {/* Game Layer */}
          <div className="absolute inset-0">
             {(gameState === GameState.PLAYING || gameState === GameState.GAMEOVER) && (
               <GameEngine 
                 gameState={gameState} 
                 skin={currentSkin} 
                 hat={currentHat}
                 level={currentLevel} 
                 onGameOver={handleGameOver}
               />
             )}
          </div>

          {/* UI Layer */}
          <div className="absolute inset-0 z-10 pointer-events-none">
            {gameState === GameState.MENU && (
              <div className="pointer-events-auto h-full">
                <Menu 
                  onStart={resetAndPlay} 
                  onOpenShop={() => setGameState(GameState.SHOP)}
                  onOpenLevelSelect={() => setGameState(GameState.LEVEL_SELECT)}
                />
              </div>
            )}

            {gameState === GameState.SHOP && (
              <div className="pointer-events-auto h-full">
                <Shop 
                  currentSkin={currentSkin} 
                  currentHat={currentHat}
                  onSelectSkin={setCurrentSkin} 
                  onSelectHat={setCurrentHat}
                  onBack={() => setGameState(GameState.MENU)} 
                />
              </div>
            )}

            {gameState === GameState.LEVEL_SELECT && (
              <div className="pointer-events-auto h-full">
                <LevelSelect 
                  onSelect={selectLevelAndGo} 
                  onBack={() => setGameState(GameState.MENU)} 
                />
              </div>
            )}

            {gameState === GameState.GAMEOVER && (
              <div className="pointer-events-auto flex flex-col items-center justify-center h-full bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
                <div className="bg-slate-900/95 p-12 rounded-3xl border-2 border-red-500 shadow-[0_0_50px_rgba(239,68,68,0.3)] text-center">
                    <h2 className="text-7xl font-black text-red-500 mb-2 italic font-title tracking-tighter">CRASHED!</h2>
                    <div className="text-slate-300 text-2xl mb-12 font-mono uppercase tracking-widest">
                      PROGESS: <span className="text-white">{score}%</span>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-6 justify-center">
                    <button 
                        onClick={resetAndPlay}
                        className="px-12 py-5 bg-white text-black font-black rounded-xl hover:bg-cyan-400 transition-all transform hover:scale-110 active:scale-95 text-2xl shadow-xl"
                    >
                        RETRY
                    </button>
                    <button 
                        onClick={() => setGameState(GameState.MENU)}
                        className="px-12 py-5 bg-slate-800 text-white font-black rounded-xl hover:bg-slate-700 transition-all transform hover:scale-110 active:scale-95 text-2xl"
                    >
                        MENU
                    </button>
                    </div>
                </div>
              </div>
            )}
          </div>

          {/* HUD Layer */}
          {gameState === GameState.PLAYING && (
            <div className="absolute top-6 left-0 right-0 flex justify-between px-10 pointer-events-none z-20">
              <div className="bg-black/40 backdrop-blur-md px-4 py-2 rounded-lg border border-white/10">
                <span className="text-slate-400 text-[10px] block uppercase tracking-[0.2em]">Progress</span>
                <span className="text-cyan-400 font-mono text-3xl font-bold">{score}%</span>
              </div>
              <div className="text-right bg-black/40 backdrop-blur-md px-4 py-2 rounded-lg border border-white/10">
                <span className="text-slate-400 text-[10px] block uppercase tracking-[0.2em]">Level</span>
                <span className="text-white font-black italic text-xl uppercase tracking-tighter">{currentLevel.name}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
