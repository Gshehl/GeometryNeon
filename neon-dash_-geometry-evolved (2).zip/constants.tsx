
import { Skin, Environment, Level, Hat } from './types';

export const HATS: Hat[] = [
  { id: 'none', name: 'No Hat', icon: 'fa-ban' },
  { id: 'crown', name: 'King', icon: 'fa-crown' },
  { id: 'wizard', name: 'Mage', icon: 'fa-hat-wizard' },
  { id: 'cowboy', name: 'Cowboy', icon: 'fa-hat-cowboy' },
  { id: 'grad', name: 'Scholar', icon: 'fa-graduation-cap' },
];

export const SKINS: Skin[] = [
  { id: 'cube-1', name: 'Neon Classic', color: '#00f2ff', secondaryColor: '#ffffff', icon: 'fa-square', trailColor: 'rgba(0, 242, 255, 0.4)' },
  { id: 'cube-2', name: 'Vaporwave', color: '#ff00ff', secondaryColor: '#00ffff', icon: 'fa-cube', trailColor: 'rgba(255, 0, 255, 0.4)' },
  { id: 'cube-3', name: 'Lava Core', color: '#ff4d00', secondaryColor: '#ffee00', icon: 'fa-shapes', trailColor: 'rgba(255, 77, 0, 0.4)' },
  { id: 'cube-4', name: 'Emerald', color: '#00ff6a', secondaryColor: '#ffffff', icon: 'fa-diamond', trailColor: 'rgba(0, 255, 106, 0.4)' },
  { id: 'cube-5', name: 'Void', color: '#5e00ff', secondaryColor: '#ff0066', icon: 'fa-ghost', trailColor: 'rgba(94, 0, 255, 0.4)' },
  { id: 'cube-6', name: 'Gold Rush', color: '#ffd700', secondaryColor: '#000000', icon: 'fa-trophy', trailColor: 'rgba(255, 215, 0, 0.4)' },
  { id: 'cube-7', name: 'Stealth', color: '#333333', secondaryColor: '#ff0000', icon: 'fa-user-ninja', trailColor: 'rgba(51, 51, 51, 0.4)' },
];

export const ENVIRONMENTS: Environment[] = [
  { id: 'env-1', name: 'Cyber City', bgColor: '#0a0a1a', floorColor: '#1a1a3a', gradient: 'from-blue-900 via-slate-900 to-black', musicUrl: '#' },
  { id: 'env-2', name: 'Magma Chamber', bgColor: '#1a0505', floorColor: '#3d0a0a', gradient: 'from-red-950 via-orange-950 to-black', musicUrl: '#' },
  { id: 'env-3', name: 'Deep Space', bgColor: '#050a0a', floorColor: '#0a1a1a', gradient: 'from-teal-950 via-emerald-950 to-black', musicUrl: '#' }
];

export const LEVELS: Level[] = [
  {
    id: 'lvl-1',
    name: 'Stereo Madness',
    difficulty: 'Easy',
    environmentId: 'env-1',
    obstacles: [
      { x: 800, y: 0, type: 'spike' },
      { x: 1200, y: 0, type: 'spike' },
      { x: 1500, y: 0, type: 'block' },
      { x: 1800, y: 0, type: 'spike' },
      { x: 2100, y: 0, type: 'spike' },
      { x: 2160, y: 0, type: 'spike' },
      { x: 2500, y: 60, type: 'block' },
      { x: 2500, y: 0, type: 'block' },
      { x: 2800, y: 0, type: 'spike' },
      { x: 3200, y: 0, type: 'spike' },
      { x: 3500, y: 0, type: 'block' },
      { x: 3500, y: 50, type: 'block' },
    ]
  },
  {
    id: 'lvl-2',
    name: 'Polargeist',
    difficulty: 'Medium',
    environmentId: 'env-3',
    obstacles: [
      { x: 600, y: 0, type: 'spike' },
      { x: 900, y: 0, type: 'block' },
      { x: 1200, y: 0, type: 'spike' },
      { x: 1500, y: 0, type: 'spike' },
      { x: 1800, y: 60, type: 'block' },
      { x: 2100, y: 0, type: 'spike' },
      { x: 2400, y: 120, type: 'block' },
      { x: 2700, y: 0, type: 'spike' },
      { x: 3000, y: 0, type: 'spike' },
    ]
  },
  {
    id: 'lvl-3',
    name: 'Deadlocked',
    difficulty: 'Demon',
    environmentId: 'env-2',
    obstacles: [
      { x: 500, y: 0, type: 'spike' },
      { x: 700, y: 0, type: 'spike' },
      { x: 1000, y: 60, type: 'block' },
      { x: 1200, y: 0, type: 'spike' },
      { x: 1300, y: 0, type: 'spike' },
      { x: 1400, y: 0, type: 'spike' },
      { x: 1700, y: 120, type: 'block' },
      { x: 1900, y: 60, type: 'block' },
      { x: 2200, y: 0, type: 'spike' },
      { x: 2500, y: 0, type: 'spike' },
      { x: 2550, y: 0, type: 'spike' },
      { x: 2600, y: 0, type: 'spike' },
    ]
  }
];

export const GRAVITY = 0.8;
export const JUMP_FORCE = -14;
export const SPEED = 6;
export const PLAYER_SIZE = 50;
export const GROUND_Y = 500;
